from time import time, sleep

for i in range(10):
	print(time())
	sleep(1)